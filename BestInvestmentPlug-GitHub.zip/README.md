# Best Investment Plug — GitHub Demo

Static front-end demonstration.

## GitHub Pages
1. Create a GitHub repository.
2. Upload the contents of this project.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**.
5. Use the branch containing the `site` folder (or move the contents of `site` to the repository root if your Pages configuration does not support `/site`).
6. Open the generated Pages address.

The public demo intentionally does not accept or route real cryptocurrency.
